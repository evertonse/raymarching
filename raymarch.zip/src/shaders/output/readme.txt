Dumps and generated shaders from #include or possibly other directives
